function encode() {
    const input = document.getElementById('input').value;
    const method = document.getElementById('method-select').value;
    let output = '';

    switch (method) {
        case 'base64':
            output = btoa(input); // Encode with Base64
            break;
        case 'caesar':
            output = caesarCipher(input, 3); // Example Caesar Cipher encoding with shift of 3
            break;
        case 'aes':
            output = "AES encoding requires a key and initialization vector."; // Placeholder
            break;
        default:
            output = "Please select a valid encoding method.";
    }

    document.getElementById('output').value = output;
}

function decode() {
    const input = document.getElementById('input').value;
    const method = document.getElementById('method-select').value;
    let output = '';

    switch (method) {
        case 'base64':
            output = atob(input); // Decode Base64
            break;
        case 'caesar':
            output = caesarCipher(input, -3); // Example Caesar Cipher decoding with a shift of -3
            break;
        case 'aes':
            output = "AES decoding requires a key and initialization vector."; // Placeholder
            break;
        default:
            output = "Please select a valid decoding method.";
    }

    document.getElementById('output').value = output;
}

function caesarCipher(str, shift) {
    return str
        .split('')
        .map(char => {
            const code = char.charCodeAt(0);
            if (code >= 65 && code <= 90) { // Uppercase letters
                return String.fromCharCode(((code - 65 + shift + 26) % 26) + 65);
            } else if (code >= 97 && code <= 122) { // Lowercase letters
                return String.fromCharCode(((code - 97 + shift + 26) % 26) + 97);
            } else {
                return char;
            }
        })
        .join('');
}
